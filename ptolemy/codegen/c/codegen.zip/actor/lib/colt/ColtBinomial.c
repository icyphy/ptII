
/*** binomialDistributionBlock ***/
$ref(output) = ColtRandomSource_BinomialDistribution($ref(n), $ref(p), &$actorSymbol(current));
/**/
