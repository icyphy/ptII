/*** fireBlock ***/
$ref(output) = $ref(input) ? false : true;
/**/
