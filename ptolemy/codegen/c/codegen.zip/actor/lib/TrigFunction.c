/***sinBlock***/
$ref(output) = sin($ref(input));
/**/


/***asinBlock***/
$ref(output) = asin($ref(input));
/**/


/***cosBlock***/
$ref(output) = cos($ref(input));
/**/


/***acosBlock***/
$ref(output) = acos($ref(input));
/**/


/***tanBlock***/
$ref(output) = tan($ref(input));
/**/


/***atanBlock***/
$ref(output) = atan($ref(input));
/**/

