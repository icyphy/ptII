$Id: README.txt,v 1.1 2007/05/11 14:09:44 cxh Exp $
See package.html
