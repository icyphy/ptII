
/*** poissonDistributionBlock ***/
$ref(output) = ColtRandomSource_PoissonDistribution($ref(mean), &$actorSymbol(current));
/**/
