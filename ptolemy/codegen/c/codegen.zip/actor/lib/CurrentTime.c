/***fireBlock***/
/* If this fails to compile because _currentTime is not defined
 * then be sure the top level director has period set to something
 * other than 0.0.
 */
$ref(output) = _currentTime;
/**/
