/*** fireBlock ***/
if ($ref(control)) {
    $ref(trueOutput) = $ref(input);
} else {
    $ref(falseOutput) = $ref(input);
}
/**/
