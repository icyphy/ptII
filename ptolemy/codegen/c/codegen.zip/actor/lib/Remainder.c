/***fireBlock***/
$ref(output) = remainder($ref(input), $val(divisor));
/**/
