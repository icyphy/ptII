Custom Input Boxes in Actor Configuration Dialog

A simple actor with a parameter consisting of a text field and a button to pop up a 
dialog for entering a string (which is then displayed in the text field).

This code uses custom input box classes defined outside of the Ptolemy II tree 
To run this example, your classpath must include the directory 
where this model is found, for example, under Unix and Mac OS X
   export CLASSPATH=.:${PTII}
   vergil InputDialogExample.xml

InputDialog is an actor defined in org/examples/actors/InputDialog.java
InputDialog uses org/examples/data/expr/InputDialogParameter.java

Demonstration Author: Christopher Brooks
http://bugzilla.ecoinformatics.org/show_bug.cgi?id=3471

Actor Author: Peter Reutemann
http://www.scms.waikato.ac.nz/~fracpete/downloads/ptolemy/custom_query_boxes2/