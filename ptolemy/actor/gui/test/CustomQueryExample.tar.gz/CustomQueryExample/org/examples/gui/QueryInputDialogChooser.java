/*

 Copyright (c) 1997-2008 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */

package org.examples.gui;

import ptolemy.gui.Query;
import ptolemy.gui.QueryChooser;
import ptolemy.gui.Query.QueryActionListener;
import ptolemy.gui.Query.QueryFocusListener;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * Panel containing an entry box and a Weka GenericObjectEditor.
 * 
 * @author  fracpete (fracpete at waikato dot ac dot nz)
 * @version $Revision$
 */
public class QueryInputDialogChooser
  extends QueryChooser {

  /** for serialization. */
  private static final long serialVersionUID = 8137272881666736002L;

  /** the current string being edited. */
  private String _current;

  /** the box with the commandline. */
  private JTextField _entryBox;

  /**
   * Initializes the chooser.
   * 
   * @param owner	the owning query
   * @param name	the name of the component
   * @param defValue	the default object
   */
  public QueryInputDialogChooser(
      Query owner,
      String name, 
      String defValue) {

    this(owner, name, defValue, Color.white, Color.black);
  }

  /**
   * Initializes the chooser.
   * 
   * @param owner	the owning query
   * @param name	the name of the component
   * @param defValue	the default object
   * @param background	the background color
   * @param foreground	the foreground color
   */
  public QueryInputDialogChooser(
      Query owner,
      String name, 
      String defValue, 
      Color background, 
      Color foreground) {

    super(owner, name, background, foreground);

    _entryBox = new JTextField("", getOwner().getTextWidth());
    _entryBox.setBackground(getBackgroundColor());
    _entryBox.setForeground(getForegroundColor());
    _entryBox.setEditable(false);
    setQueryValue(defValue);

    JButton button = new JButton("...");
    button.addActionListener(this);
    add(_entryBox);
    add(button);

    // Add the listener last so that there is no notification
    // of the first value.
    _entryBox.addActionListener(new QueryActionListener(getOwner(), getName()));

    // Add a listener for loss of focus.  When the entry gains
    // and then loses focus, listeners are notified of an update,
    // but only if the value has changed since the last notification.
    // FIXME: Unfortunately, Java calls this listener some random
    // time after the window has been closed.  It is not even a
    // a queued event when the window is closed.  Thus, we have
    // a subtle bug where if you enter a value in a line, do not
    // hit return, and then click on the X to close the window,
    // the value is restored to the original, and then sometime
    // later, the focus is lost and the entered value becomes
    // the value of the parameter.  I don't know of any workaround.
    _entryBox.addFocusListener(new QueryFocusListener(getOwner(), getName()));
  }

  public void actionPerformed(ActionEvent e) {
    String result = JOptionPane.showInputDialog(this, "Please enter a string", _current);
    if (result != null) {
      _current = result;
      _entryBox.setText(result);
      _notifyListeners(getName());
    }
  }

  /**
   * Returns the current string.
   * 
   * @return		the string
   */
  public String getQueryValue() {
    return _current;
  }

  /**
   * Sets the current string.
   * 
   * @param value	the string to use
   */
  public void setQueryValue(String value) {
    _current = value;
    _entryBox.setText(value);
  }
}
