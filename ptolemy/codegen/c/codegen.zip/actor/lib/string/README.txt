$Id: README.txt,v 1.1 2006/03/16 16:28:41 cxh Exp $
See package.html
