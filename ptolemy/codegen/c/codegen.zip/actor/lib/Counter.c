/***incrementBlock***/
$ref(output)++;
/**/

/***decrementBlock***/
$ref(output)--;
/**/
