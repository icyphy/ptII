/***fireBlock***/
$ref(x) = $ref(magnitude) * cos($ref(angle));
$ref(y) = $ref(magnitude) * sin($ref(angle));
/**/
