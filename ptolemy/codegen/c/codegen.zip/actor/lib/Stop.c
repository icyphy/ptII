/*** preinitBlock ***/
int $actorSymbol(i);
/**/

/*** fireBlock($channel) ***/
if ($ref(input#$channel)) {
    exit(0);
}
/**/

