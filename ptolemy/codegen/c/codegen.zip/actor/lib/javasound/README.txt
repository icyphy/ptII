$Id: README.txt,v 1.1 2005/07/12 17:40:47 cxh Exp $
See package.html
