/***fireBlock***/
if ($ref(input)) {
    $ref(output) = $val(($cgType(output)) trueValue);
} else {
    $ref(output) = $val(($cgType(output)) falseValue);
}
/**/
