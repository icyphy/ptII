/***fireBlock($channel)***/
// consume the input token.
$ref(input#$channel);
/**/
