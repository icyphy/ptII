$Id: README.txt,v 1.1 2006/03/17 04:54:07 cxh Exp $
See package.html
