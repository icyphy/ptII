/*** fireBlock ***/
$ref(output) = strlen($ref(input));
/**/

