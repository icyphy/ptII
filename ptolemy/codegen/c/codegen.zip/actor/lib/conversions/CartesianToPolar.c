/***fireBlock***/
$ref(magnitude) = sqrt(($ref(x) * $ref(x)) + ($ref(y) * $ref(y)));
$ref(angle) = atan2($ref(y), $ref(x));
/**/
