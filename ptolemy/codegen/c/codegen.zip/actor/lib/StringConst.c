/*** initBlock ***/
$ref(output) = $val(value);
/**/
