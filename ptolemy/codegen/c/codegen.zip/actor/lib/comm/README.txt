$Id: README.txt,v 1.1 2006/03/16 16:25:21 cxh Exp $
See package.html
