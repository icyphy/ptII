/*** fireBlock ***/
$ref(output) = $ref(input).payload.Array->size;
/**/

