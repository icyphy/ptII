/***fireBlock***/
if ($ref(input) >= 0 && $ref(input) < $size(table)) {
    $ref(output) = $ref(table, $ref(input));
}
/**/
