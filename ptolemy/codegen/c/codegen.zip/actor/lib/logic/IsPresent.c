/*** outputBlock ($channel)***/
// FIXME: This is an assumption we make in sdf.
$ref(output#$channel) = true;
/**/
