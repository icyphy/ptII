/***fireBlock($channel)***/
$ref(output#$channel) = $ref(($cgType(output)) input#$channel);
/**/
