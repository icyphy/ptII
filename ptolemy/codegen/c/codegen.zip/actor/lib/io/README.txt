<!-- $Id: README.txt,v 1.2 2006/03/17 05:24:35 cxh Exp $ -->
<html>
<head>
<title>ptolemy.codegen.c.actor.lib.io</title>
</head>
<body>
C code generation templates for input/output actors.
<p>
@since Ptolemy II 5.1
</body>
</html>
