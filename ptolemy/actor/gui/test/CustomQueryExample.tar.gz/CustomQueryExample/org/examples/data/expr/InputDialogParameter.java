/*

 Copyright (c) 1997-2008 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */

package org.examples.data.expr;

import ptolemy.actor.gui.PtolemyQuery;
import ptolemy.data.StringToken;
import ptolemy.actor.gui.CustomQueryBoxParameter;
import ptolemy.data.expr.Parameter;
import ptolemy.data.expr.StringParameter;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;
import ptolemy.kernel.util.NamedObj;
import ptolemy.kernel.util.Settable;

import javax.swing.Box;

import org.examples.gui.QueryInputDialogChooser;


//////////////////////////////////////////////////////////////////////////
//// InputDialogParameter

/**
 * Parameter class for demonstrating the proprosed flexible Parameter/Chooser
 * architecture. Based on the StringParameter class. 
 * 
 * @author FracPete (fracpete at waikato dot ac dot nz)
 * @version $Revision$
 * @see StringParameter
 */
public class InputDialogParameter
  extends StringParameter
  implements CustomQueryBoxParameter {
  
  /** for serialization. */
  private static final long serialVersionUID = -7121249147187667582L;
  
  /** the attribute for the default value. */
  public final static String ATT_DEFVALUE = "defValue";

  /** 
   * Construct an attribute with the given name contained by the
   * specified container. The container argument must not be null, or a
   * NullPointerException will be thrown.  This attribute will use the
   * workspace of the container for synchronization and version counts.
   * If the name argument is null, then the name is set to the empty
   * string. Increment the version of the workspace.
   * 
   * @param container 			The container.
   * @param name 			The name of this attribute.
   * @throws IllegalActionException 	If the attribute is not of an acceptable 
   * 					class for the container, or if the name 
   * 					contains a period.
   * @throws NameDuplicationException 	If the name coincides with an attribute 
   * 					already in the container.
   */
  public InputDialogParameter(NamedObj container, String name)
    throws IllegalActionException, NameDuplicationException {
    
    super(container, name);
  }
  
  /**
   * Returns the current string.
   * 
   * @return		the string
   */
  public String asString() throws IllegalActionException {
    return stringValue();
  }

  /**
   * Creates a customized query box for the given query.
   * 
   * @param query			the query to add the custom box to
   * @param attribute			the attribute the query box is associated with
   * @throws IllegalActionException 	if something goes wrong
   */
  public Box createQueryBox(PtolemyQuery query, Settable attribute) throws IllegalActionException {
    String 			name;
    Parameter 			att;
    String 			defValue;
    QueryInputDialogChooser 	result;
    
    name = attribute.getName();

    // default value
    defValue = null;
    att = (Parameter) ((NamedObj) attribute).getAttribute(
	InputDialogParameter.ATT_DEFVALUE, Parameter.class);
    if (att != null)
      defValue = ((StringToken) att.getToken()).stringValue();
    if (((InputDialogParameter) attribute).stringValue().length() != 0)
      defValue = ((InputDialogParameter) attribute).stringValue();

    // create chooser
    result = new QueryInputDialogChooser(
	query, name, defValue, 
	PtolemyQuery.preferredBackgroundColor(attribute), 
	PtolemyQuery.preferredForegroundColor(attribute));
    
    return result;
  }
}
