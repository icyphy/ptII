/***fireBlock***/
$ref(output) =   ( $ref(input) < $val(bottom) )? $val(bottom) :
    ( $ref(input) > $val(top) )? $val(top) :
        $ref(input);
/**/
