/*** fireBlock ***/
$ref(output) = !strcmp($ref(firstString), $ref(secondString));
/**/
