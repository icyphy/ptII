/*** fireBlock ***/
if ($ref(control)) {
    $ref(output) = $ref(trueInput);
} else {
    $ref(output) = $ref(falseInput);
}
/**/
