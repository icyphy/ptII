$Id: README.txt,v 1.1 2006/03/17 04:52:27 cxh Exp $
See package.html
