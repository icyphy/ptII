/*** fireBlock ($type)***/
if ($ref(select)) {
    $ref(output) = $ref(($type) trueInput);
} else {
    $ref(output) = $ref(($type) falseInput);
}
/**/
