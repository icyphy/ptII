/*** fireBlock ***/
    $ref(x) = $ref(output).payload.Complex->real;
    $ref(y) = $ref(output).payload.Complex->imag;
/**/
