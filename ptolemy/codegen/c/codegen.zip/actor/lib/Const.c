/***fireBlock***/
$ref(output) = $val(($cgType(output)) value);
/**/
