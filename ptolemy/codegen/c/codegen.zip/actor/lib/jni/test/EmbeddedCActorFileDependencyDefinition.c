/* $Id: EmbeddedCActorFileDependencyDefinition.c,v 1.1 2007/08/20 05:24:51 cxh Exp $ */
/* A simple test for the fileDependency block */
int fortytwo(int input) {
    return input * 42;
}
