/*** fireBlock($channel) ***/
$ref(output#$channel) = $ref(input#$channel);
/**/

